<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Laravel\Socialite\Facades\Socialite;

use App\User;
use App\SocialProfile;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::DASHBOARD;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Redirect the user to the external authentication website.
     *
     * @return \Illuminate\Http\Response
     */

    public function redirectToProvider()
    {   
       return Socialite::driver('google')->redirect();
    }

    /**
     * Obtain the user information from external website.
     *
     * @return \Illuminate\Http\Response
     */

    public function handleProviderCallback(Request $request)
    {
        /** if the user denise permission on google to provide login information then redirect to login page */ 
        if($request->get('error')){
            return redirect()->route('login');
        }

        $google_user = Socialite::driver('google')->user();
        $user_with_google_email = User::where('email', $google_user->getEmail())->first();
        $user_with_google_id = User::where('google_id', $google_user->getId())->first();
        
        /** 
         * if the user with this email has not been registered before then create account
         * using the information and avatar provided by google. is important to make
         * sure there is not a user with the google_id because there is a possbility that it
         * is registered but changed the email.
         */

        if(!$user_with_google_email and !$user_with_google_id){
            $user_with_google_email = User::create([
            'google_id' => $google_user->getId(),
            'email' => $google_user->getEmail(), 
            'avatar_url' => 'http://localhost/tipmedash/public/images/default-profile-pic1.jpg',
            'reputation_score' => 10,
            ]);
        }

        /**
         * user with this email exists but has the google_id field null
         * continue and assign one.
         */

        if($user_with_google_email and !$user_with_google_email->google_id){
            $user_with_google_email->google_id = $google_user->getId();
            $user_with_google_email->save();
        }

        /** find the user using the google id and do login */
        
        $user_with_google_id = User::where('google_id', $google_user->getId())->first();

        auth()->login($user_with_google_id);
        return redirect()->route('dashboard');
    }
}
