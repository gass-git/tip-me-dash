
<?php $__env->startSection('content'); ?>
<body>
    <section class="dashboard container">
        
        <div class="row">
            <div id="wrapper" class="container mx-auto">
                <div class="row">

                    <!-- welcome to the dashboard section -->
                    <div id="welcome" class="ml-3 pt-3">
                        
                        <!-- if it has a username -->
                        <?php if($username = Auth::user()->username): ?>
                            
                            <a id="username" href="<?php echo e(route('user_page',$username)); ?>"><?php echo e($username); ?></a>, welcome to your dashboard
                        
                        <!-- if it doesnt have a username -->
                        <?php else: ?>
                            <img src="http://localhost/tipmedash/public/images/dashy-laptop-90.png">Welcome to your dashboard 
                        <?php endif; ?>

                    </div>
                    <!-- end of welcome to the dashboard section -->

                </div>
            </div>
        </div> 

        <!-- pending card -->
        <?php if(!Auth::user()->wallet_address or !Auth::user()->username): ?>
                
            <div class="row">
                <div id="wrapper" class="container mx-auto">
                    <div class="row">

                        <!-- username pending -->
                        <?php if(!Auth::user()->username): ?>
                            <div class="alert alert-light border" role="alert">
                            <i class="fas fa-glasses mr-2"></i>It seems you haven't created a username yet. 
                                If you wish to have a TMD page you can 
                                <a href="<?php echo e(route('edit_profile')); ?>"> create one here</a>.
                            </div>
                        <?php endif; ?>
                        <!---------------------->

                        <!-- wallet address pending -->
                        <?php if(!Auth::user()->wallet_address): ?>
                            <div class="alert alert-light border" role="alert">
                            <i class="fas fa-glasses mr-2"></i>You haven't set up your Dash wallet address yet.
                                If you wish to start receiving tips you can <a href="<?php echo e(route('edit_profile')); ?>">enter one here</a>.
                            </div>
                        <?php endif; ?>
                        <!----------------------------->
                        
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!------ pending card end ------->

        <!-- summary -->   
        <div class="row">
            <div id="wrapper" class="container border pl-3 pr-3 mx-auto">
                <div class="row">

                    <!-- reputation -->
                    <div id="rep-col" class="col-md-3 p-3">
                        <div id="rep-card" class="card text-white">
                            <div class="card-body">
                                <h5 class="card-title">Reputation</h5>
                                <p class="card-text"><?php echo e(Auth::user()->reputation_score); ?></p>
                            </div>
                        </div>
                    </div>
                    <!---------------->

                    <!-- page link -->
                    <div class="col-md-9 p-3">
                        <div id="page-link-card" class="card text-white bg-primary">
                            <div class="card-body pr-1">
                                <h5 class="card-title">Share your page link</h5>
                                
                                <!-- does the user have a username? -->
                                <?php if($username = Auth::user()->username): ?>
                                    <form class="form-inline mr-0">
                                        <input id="share-link" type="text" class="form-control w-75" value="http://tipmedash.com/<?php echo e($username); ?>" id="user_page">
                                        <button class="ml-2 btn btn-info" onclick="copy_url()" id="btn">Copy</button>
                                    </form>
                                <?php else: ?>
                                    <p>
                                    <i class="fas fa-exclamation mr-2"></i>Not available. You need to <a href="<?php echo e(route('edit_profile')); ?>" style="color:turquoise;">create a username</a> to have your own page link.
                                    </p>
                                <?php endif; ?>

                                <!-- script for copy button -->
                                <script>
                                    function copy_url() {
                                    var url = document.getElementById("user_page");
                                    url.select();
                                    url.setSelectionRange(0, 200)
                                    document.execCommand("copy");

                                    var btn = document.getElementById("btn");
                                    btn.innerHTML = "Copied";
                                    setTimeout(() => {document.getElementById("btn").innerHTML = "Copy"}, 2000);
                                    }
                                </script>     
                                <!--------------------------->
                            </div>
                        </div>
                    </div>
                    <!-- end of page link --->
                </div>
            </div>
        </div>
        <!------ end of summary ------->                               

        <!-- new commers -->
        <div class="row">
            <div id="wrapper" class="container mt-3 pl-3 pb-0 pr-3 mx-auto">
                <div class="row">
                    <div id="newcomers" class="alert border m-0" role="alert">
                    <i class="fas fa-child mr-2"></i><b> Discover</b> newcomers
                        <a href="newcomers"> here</a>
                    </div>
                </div>
            </div>
        </div>
        <!----------------->

        <div class="title-1">RECENT ACTIVITY</div>

        <!-- recent -->
        <div class="row">
            <div id="wrapper" class="mt-0 mx-auto">
                <ul class="list-group" style="width:100%;">

                    <?php if(count($recent_logs) < 1): ?>
                        <div id="no-activity" class="alert border" role="alert">
                           You don't have any recent activity..
                        </div>              
                    <?php else: ?>
                        <?php $__currentLoopData = $recent_logs->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php if($event->rep_change > 0): ?>
                                <span id="rep-badge" class="badge badge-success mr-1">+<?php echo e($event->rep_change); ?></span>
                            <?php else: ?>
                                <span id="rep-badge" class="badge badge-danger mr-1"><?php echo e($event->rep_change); ?></span>
                            <?php endif; ?>

                            <!-- show username with a link to their page -->
                            <?php if($username = App\User::where('id',$event->from_user_id)->first()->username): ?>                  
                                <a class="visitor-username" href="<?php echo e(route('user_page',$username)); ?>"><?php echo e($username); ?></a>
                            <?php else: ?>
                                <span style="font-weight:bold;">Someone</span><!-- note: show "someone" if the user doesn't have a username -->  
                            <?php endif; ?>
                            <!--------------------------------------------->

                            <?php if($event->log === 'wrote on your page.'): ?>
                                <a href="<?php echo e(route('user_page',Auth::user()->username)); ?>"><?php echo e($event->log); ?></a>
                            <?php else: ?>
                                <?php echo e($event->log); ?>

                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
        <!-------------->

        <div class="title-1">USERS I LIKE</div>

        <!-- users liked -->
        <div class="row">
            <div class="content-wrapper mt-0 mx-auto" style="width:80%;">
                        
                <?php if(count($users_liked) < 1): ?>
                    <div id="no-likes" class="alert border" role="alert">
                        You still don't like any user..
                    </div>
                <?php else: ?>

                    <div class="list-group" style="width:100%;">

                    <?php $__currentLoopData = $users_liked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_liked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $username = App\User::where('id',$user_liked->recipient_id)->first()->username;
                            $avatar_url = App\User::where('id',$user_liked->recipient_id)->first()->avatar_url;
                        ?>

                        <a class="list-group-item list-group-item-action" href="<?php echo e(route('user_page',$username)); ?>" >
                            <img id="avatar" src="<?php echo e($avatar_url); ?>"></img>
                            <span class="ml-2" style="text-transform: capitalize;"><?php echo e($username); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                
                    </div>
                    <div class="mt-3"><?php echo e($users_liked->links()); ?></div>
                <?php endif; ?>

            </div>   
        </div>
        <!-------------------->

    </section>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tipmedash\resources\views/dashboard.blade.php ENDPATH**/ ?>