

<?php $__env->startSection('content'); ?>
<body>
    <section class="acc-home container" style="padding:20px; margin-top:50px; max-width:1000px;">     
        
        <!-- welcome to acc start -->
        <div class="card shadow-sm m-3" style="">
            <div class="row">
                <div class="col-md-3 align-items-center border p-3" style="text-align: center;">
                    <img src="<?php echo e(Auth::user()->avatar_url); ?>" style="border-radius:50%; width:150px;">
                </div>
                <div class="col-md-5 border p-3" style="font-size:40px; font-weight:600; ">
                Welcome <?php echo e(Auth::user()->username); ?>

                </div>
                <div class="col-md-4" style="display: flex; align-items:center;">
                <a class="btn btn-outline-warning my-2 my-sm-0 mr-2" href="<?php echo e(route('edit_profile')); ?>">Complete your profile</a>
                </div>
            </div>
        </div>
        <!-- end of welcome to acc -->
        
            <!-- checklist -->
            <div class="card shadow-sm m-3" style="">
            <div class="row">
                <div class="col-md-3 align-items-center border p-5" style="text-align: center;">
                   CHECKLIST
                </div>
                <div class="col-md-5 border p-5" style="font-size:40px; font-weight:600; ">
                   
                </div>
                <div class="col-md-4" style="display: flex; align-items:center;">
                   
                </div>
            </div>
        </div>
        <!-- checklist -->

        <!-- overview -->
        <div class="card shadow-sm m-3" style="">
            <div class="row">
                <div class="col-md-3 align-items-center border p-5" style="text-align: center;">
                    OVERVIEW
                </div>
                <div class="col-md-5 border p-5" style="font-size:40px; font-weight:600; ">
                   
                </div>
                <div class="col-md-4" style="display: flex; align-items:center;">
                 
                </div>
            </div>
        </div>
        <!-- end of overview -->

        <!-- recent -->
        <div class="card shadow-sm m-3" style="">
            <div class="row">
                <div class="col-md-3 align-items-center border p-5" style="text-align: center;">
                    RECENT
                </div>
                <div class="col-md-5 border p-5" style="font-size:40px; font-weight:600; ">
                
                </div>
                <div class="col-md-4" style="display: flex; align-items:center;">
                   
                </div>
            </div>
        </div>
        <!-- recernt -->


      

    </section>

</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tipmedash\resources\views/home.blade.php ENDPATH**/ ?>