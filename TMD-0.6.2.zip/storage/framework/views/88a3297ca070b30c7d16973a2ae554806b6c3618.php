<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/pin-32.png')); ?>">

    <!-- cookies -->
    <script src="https://cdn.jsdelivr.net/npm/js-cookie@rc/dist/js.cookie.min.js"></script>
    <!-- app js -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <!-- popper js -->
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- main js -->
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    <!-- emoji js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.2/emojionearea.min.js"></script>
    <!-- sweet alert 2 -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>


    <!-- emoji css  -->    
    <link rel="stylesheet" href="<?php echo e(asset('css/emojionearea.css')); ?>">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <!-- main css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <!-- font awesome css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.css')); ?>">
    
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
</head>

    <!-- nav bar -->
    <nav class="navbar p-0">
        <a class="navbar-brand ml-5 mr-0 p-0" href="<?php echo e(url('/')); ?>">
            <div class="container pr-0">
                    <img class="mr-3" src="<?php echo e(asset('images/logo9.png')); ?>" height="30">
                    <div class="brand-text">Tip Me Dash</div>
            </div>
        </a>

        <?php if(auth()->guard()->guest()): ?>
        <!-- authentication Links -->
        <form id="auth-links" class="form-inline mr-5 p-0">
            <a class="btn btn-outline-light ml-0 my-2 my-sm-0 mr-2" href="<?php echo e(route('login')); ?>">Login</a>
            <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Sign up</a>
        </form> 
        
        <?php else: ?>
        <!-- navbar dropdown right section -->
        <ul id="logged-in" class="form-inline p-0 my-2 my-lg-0 mr-5">
            
            <!-- navbar avatar dropdown button -->
            <a id="navbarDropdown" class="nav-link dropdown-toggle p-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                
                <!-- avatar -->
                <?php if(auth()->guard()->check()): ?> 
                <img class="user-avatar mr-2" src="<?php echo e(Auth::user()->avatar_url); ?>">
                <?php endif; ?>
                <!------------>

            </a>
            
            <!-- dropdown navigation -->
            <div class="dropdown-menu dropdown-menu-right mr-5" aria-labelledby="navbarDropdown">
                
                <!----- edit profile link --->
                <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>

                <!-- if the user has a username show his TMD page link -->
                <?php if(Auth::user()->username): ?>
                <a class="dropdown-item" href="<?php echo e(auth()->user()->username); ?>"><?php echo e(__('View my page')); ?></a>
                <?php endif; ?>
                <!------------------------------------------------------->

                <!----- community activity --->
                <a class="dropdown-item" href="<?php echo e(route('community_activity')); ?>">Community activity</a>
                <!---------------------------->

                <!----- edit profile link --->
                <a class="dropdown-item" href="<?php echo e(route('edit_profile')); ?>"><?php echo e(__('Edit profile')); ?></a>

                <!------- logout link ------->
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?></form>

                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
                <!---------------------------->

            </div>

        </ul> 
        <?php endif; ?>
    </nav>
    <!-- end nav bar -->

    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\xampp\htdocs\tipmedash\resources\views/layouts/app.blade.php ENDPATH**/ ?>