
<?php $__env->startSection('content'); ?>
<body>
    <section class="newcomers-activity container mt-5 mx-auto" style="width:600px;">
    
        <div class="title-1">RECENTLY REGISTERED</div>

        <?php $__currentLoopData = $newcomers->take(100); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newcomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($username = $newcomer->username): ?>
                <a class="list-group-item list-group-item-action" href="<?php echo e(route('user_page',$username)); ?>" >
                    <img id="avatar" src="<?php echo e($newcomer->avatar_url); ?>" style="width:25px;height:25px;border-radius:50%;"></img>
                    <span class="ml-2" style="text-transform: capitalize; color:#008de4; font-weight:600;"><?php echo e($username); ?></span>
                    <span class="float-right">Joined in <?php echo e(date('F d,Y', strtotime($newcomer->created_at))); ?></span>
                </a>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tipmedash\resources\views/newcomers.blade.php ENDPATH**/ ?>