
<?php $__env->startSection('content'); ?>
<body>
    <section class="community-activity container mt-5 mx-auto" style="width:800px;">
    
        <!-- loop -->
        <?php $__currentLoopData = $community_activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $from = App\User::where('id',$event->from_user_id)->first();
                $to = App\User::where('id',$event->to_user_id)->first();
            ?>

            <!-- does $from have a username? -->
            <?php if($from->username): ?>

                <!-- condition to see if it's a msg or a boost -->
                <?php if($event->is_msg): ?>
                    <div class="card mb-3 mx-auto" style="width: 80%">
                        <div class="card-header">
                            <i class="fas fa-pencil-alt mr-2" style="color:#0268a8;"></i> 
                            <a class="visitor-username" href="<?php echo e(route('user_page',$from->username)); ?>">
                                <?php echo e($from->username); ?>

                            </a> 
                            wrote a message to 
                            <a class="visitor-username" href="<?php echo e(route('user_page',$to->username)); ?>">
                            <?php echo e($to->username); ?>

                            </a>
                        </div>
                        <div class="card-body text-info">
                            <p class="card-text"><?php echo e($event->msg); ?></p>
                        </div>
                    </div>
                <?php else: ?>

                <div class="alert alert-light mx-auto border" role="alert" style="width:80%;">
                    <i class="fas fa-star mr-2" style="color:#CCCC00;"></i> 
                    <a class="visitor-username" href="<?php echo e(route('user_page',$from->username)); ?>">
                        <?php echo e($from->username); ?>

                    </a>
                    boosted 
                    <a class="visitor-username" href="<?php echo e(route('user_page',$to->username)); ?>">
                        <?php echo e($to->username); ?> 
                    </a>
                    reputation.
                </div>
                    
                <?php endif; ?>

            <?php else: ?> <!-- $from does not have a username -->

                <!-- condition to see if it's a msg or a boost -->
                <?php if($event->is_msg): ?>
                    <div class="card mb-3 mx-auto" style="width: 80%">
                        <div class="card-header">
                            <i class="fas fa-pencil-alt mr-2" style="color:#0268a8;"></i> 
                            <span class="visitor-username">
                                Someone
                            </span> 
                            wrote a message to 
                            <a class="visitor-username" href="<?php echo e(route('user_page',$to->username)); ?>">
                                <?php echo e($to->username); ?>

                            </a>
                        </div>
                        <div class="card-body text-info">
                            <p class="card-text"><?php echo e($event->msg); ?></p>
                        </div>
                    </div>
                <?php else: ?>

                <div class="alert alert-light mx-auto border" role="alert" style="width:80%;">
                    <i class="fas fa-star mr-2" style="color:#CCCC00;"></i> <span style="color:#008de4">
                        Someone
                    </span>
                    boosted 
                    <a class="visitor-username" href="<?php echo e(route('user_page',$to->username)); ?>">
                        <?php echo e($to->username); ?> 
                    </a>
                    reputation.
                </div>
                    
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- end of loop -->

        <!-- pagination -->
        <div><?php echo e($community_activity->links()); ?></div>
        <!---------------->

    </section>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tipmedash\resources\views/community_activity.blade.php ENDPATH**/ ?>