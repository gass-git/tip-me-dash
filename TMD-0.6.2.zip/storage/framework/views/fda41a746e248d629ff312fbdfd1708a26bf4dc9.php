<?php $__env->startSection('content'); ?>
<body>

    <div class="login-form modal-dialog text-center" style="background-color:transparent;">
        <div class="col-sm-8 main-section">
            <div class="border modal-content">
                <div class="col-12 user-img">
                    <img src="<?php echo e(asset('images/default-profile-pic1.jpg')); ?>">
                </div>
                
                <!-- start of login form -->
                <form class="col-12" action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                    <div class="form-group">
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" onblur="this.placeholder='Email'" onfocus="this.placeholder=''" placeholder="Email" autocomplete="email" required>
                        <span class="email-icon"><img src="<?php echo e(asset('images/email-icon.png')); ?>"></span>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <input id="password" name="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  onblur="this.placeholder='Password'" onfocus="this.placeholder=''" placeholder="Password" autocomplete="current-password" required>
                        <span class="password-icon"><img src="<?php echo e(asset('images/lock-icon-2.png')); ?>"></span>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary login-btn mt-0"><i class="fas fa-sign-in-alt mr-2"></i> Log in</button>
                    <a role="button" class="btn btn-info google-btn" href="<?php echo e(url('login/google')); ?>"><i class="fab fa-google mr-2"></i>Log in with Google</a>
                </form>
                <!-- end of login form -->

                <?php if(Route::has('password.request')): ?>
                <div class="col-12 forgot-password">
                    <a href="<?php echo e(route('password.request')); ?>">Forgot your password?</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div> 

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tipmedash\resources\views/auth/login.blade.php ENDPATH**/ ?>